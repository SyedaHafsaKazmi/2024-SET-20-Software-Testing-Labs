// R1: Calculate fare for one ride
export function fareForRide(distanceKm, ratePerKm) {
    return Math.round(distanceKm * ratePerKm);
}

// R2: Calculate total fare for multiple rides
export function totalFare(rides) {
    return rides.reduce((total, ride) => {
        return total + fareForRide(ride.distanceKm, ride.ratePerKm);
    }, 0);
}

// R3: Apply peak-hour surcharge
export function applyPeakSurcharge(amount, percent) {
    return Math.round(amount + (amount * percent / 100));
}

// R4: Calculate waiting charge
export function waitingCharge(minutes) {
    return Math.max(0, minutes - 5) * 10;
}

// R5: Generate ride summary
export function rideSummary(rides, surchargePercent, minutesWaited) {
    const fare = totalFare(rides);
    const surcharge = applyPeakSurcharge(fare, surchargePercent) - fare;
    const waiting = waitingCharge(minutesWaited);

    return {
        fare: fare,
        surcharge: surcharge,
        waitingCharge: waiting,
        total: fare + surcharge + waiting
    };
}

// R6 will be implemented after writing its tests.
export function totalDistance(rides) {
    return rides.reduce((total, ride) => {
        return total + ride.distanceKm;
    }, 0);
}