import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
    fareForRide,
    totalFare,
    applyPeakSurcharge,
    waitingCharge,
    rideSummary,
    totalDistance
} from '../src/taxi.js';

// R1: fareForRide tests
describe('R1 - Fare for one ride', () => {

    test('calculates fare for a normal ride', () => {
        // Arrange
        const distance = 10;
        const rate = 25;

        // Act
        const result = fareForRide(distance, rate);

        // Assert
        assert.strictEqual(result, 250);
    });

    test('rounds fare to the nearest rupee', () => {
        const result = fareForRide(3.7, 12);
        assert.strictEqual(result, 44);
    });

    test('rounds fare upward when decimal is above .5', () => {
        const result = fareForRide(3.8, 12);
        assert.strictEqual(result, 46);
    });

    test('returns zero fare for zero distance', () => {
        const result = fareForRide(0, 30);
        assert.strictEqual(result, 0);
    });

});

// R2: totalFare tests
describe('R2 - Total fare for multiple rides', () => {

    test('calculates total fare for multiple rides', () => {
        const rides = [
            { distanceKm: 10, ratePerKm: 25 },
            { distanceKm: 3.8, ratePerKm: 12 },
            { distanceKm: 8, ratePerKm: 30 }
        ];

        const result = totalFare(rides);

        assert.strictEqual(result, 536);
    });

    test('returns zero for an empty ride list', () => {
        const result = totalFare([]);

        assert.strictEqual(result, 0);
    });

    test('rounds each ride before adding the fares', () => {
        const rides = [
            { distanceKm: 3.7, ratePerKm: 12 },
            { distanceKm: 3.7, ratePerKm: 12 }
        ];

        const result = totalFare(rides);

        assert.strictEqual(result, 88);
    });

});

// R3: applyPeakSurcharge tests
describe('R3 - Peak hour surcharge', () => {

    test('applies 20 percent surcharge', () => {
        const result = applyPeakSurcharge(1000, 20);
        assert.strictEqual(result, 1200);
    });

    test('rounds surcharge to the nearest rupee', () => {
        const result = applyPeakSurcharge(99, 15);
        assert.strictEqual(result, 114);
    });

    test('calculates surcharge on a decimal amount', () => {
        const result = applyPeakSurcharge(333, 10);
        assert.strictEqual(result, 366);
    });

    test('returns original amount when percentage is zero', () => {
        const result = applyPeakSurcharge(250, 0);
        assert.strictEqual(result, 250);
    });

});

// R4: waitingCharge tests
describe('R4 - Waiting charge', () => {

    test('charges nothing for 4 minutes', () => {
        const result = waitingCharge(4);
        assert.strictEqual(result, 0);
    });

    test('charges nothing for exactly 5 minutes', () => {
        const result = waitingCharge(5);
        assert.strictEqual(result, 0);
    });

    test('charges 10 rupees for 6 minutes', () => {
        const result = waitingCharge(6);
        assert.strictEqual(result, 10);
    });

    test('charges nothing for zero minutes', () => {
        const result = waitingCharge(0);
        assert.strictEqual(result, 0);
    });

    test('charges 100 rupees for 15 minutes', () => {
        const result = waitingCharge(15);
        assert.strictEqual(result, 100);
    });

});

// R5: rideSummary tests
describe('R5 - Ride summary', () => {

    test('calculates complete ride summary', () => {
        const rides = [
            { distanceKm: 10, ratePerKm: 25 },
            { distanceKm: 8, ratePerKm: 30 }
        ];

        const result = rideSummary(rides, 20, 9);

        assert.deepStrictEqual(result, {
            fare: 490,
            surcharge: 98,
            waitingCharge: 40,
            total: 628
        });
    });

    test('returns zero values for empty rides and short waiting', () => {
        const result = rideSummary([], 10, 3);

        assert.deepStrictEqual(result, {
            fare: 0,
            surcharge: 0,
            waitingCharge: 0,
            total: 0
        });
    });

    test('calculates summary for one ride', () => {
        const rides = [
            { distanceKm: 3.8, ratePerKm: 12 }
        ];

        const result = rideSummary(rides, 15, 6);

        assert.deepStrictEqual(result, {
            fare: 46,
            surcharge: 7,
            waitingCharge: 10,
            total: 63
        });
    });

});

// R6: totalDistance tests (Test-First Development)
describe('R6 - Total distance of rides', () => {

    test('calculates total distance for multiple rides', () => {
        const rides = [
            { distanceKm: 10, ratePerKm: 25 },
            { distanceKm: 2.5, ratePerKm: 12 },
            { distanceKm: 8, ratePerKm: 30 }
        ];

        const result = totalDistance(rides);

        assert.strictEqual(result, 20.5);
    });

    test('returns zero for an empty ride list', () => {
        const result = totalDistance([]);

        assert.strictEqual(result, 0);
    });

    test('calculates distance without using fare rates', () => {
        const rides = [
            { distanceKm: 4, ratePerKm: 100 },
            { distanceKm: 6, ratePerKm: 1 }
        ];

        const result = totalDistance(rides);

        assert.strictEqual(result, 10);
    });

});